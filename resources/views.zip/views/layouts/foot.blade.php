<!-- CORE JS FRAMEWORK - START -->
<script src="{{ asset('newdesign/assets/js/jquery.min.js') }}"></script>
<script src="{{ asset('newdesign/assets/js/jquery.easing.min.js') }}"></script>
<script src="{{ asset('newdesign/assets/plugins/bootstrap/js/bootstrap.min.js') }}"></script>
<script src="{{ asset('newdesign/assets/plugins/pace/pace.min.js') }}"></script>
<script src="{{ asset('newdesign/assets/plugins/perfect-scrollbar/perfect-scrollbar.min.js') }}"></script>
<script src="{{ asset('newdesign/assets/plugins/viewport/viewportchecker.js') }}"></script>
<!-- CORE JS FRAMEWORK - END -->

<!-- CORE TEMPLATE JS - START -->
<script src="{{ asset('newdesign/assets/js/scripts.js') }}"></script>
<!-- END CORE TEMPLATE JS - END -->

<script src="{{ asset('newdesign/jquery.dataTables.js') }}"></script>
<script src="{{ asset('newdesign/dataTables.bootstrap4.js') }}"></script>
<script src="{{ asset('newdesign/data-table.js') }}"></script>